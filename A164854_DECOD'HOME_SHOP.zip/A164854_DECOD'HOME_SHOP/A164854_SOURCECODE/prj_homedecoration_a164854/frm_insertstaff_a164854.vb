﻿Public Class frm_insertstaff_a164854

    Private Sub frm_insertstaff_a164854_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        refresh_grid()

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_STAFF_A164854"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        grd_staff.DataSource = mydatatable

    End Sub

    Private Sub clear_fields()

        txt_id.Text = ""
        txt_name.Text = ""
        txt_phoneno.Text = ""
        txt_address.Text = ""

    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click

        Dim mysql As String = "INSERT INTO TBL_STAFF_A164854 VALUES 
        ('" & txt_id.Text & "','" & txt_name.Text & "','" & txt_phoneno.Text & "','" & txt_address.Text & "')"

        Dim mywriter As New OleDb.OleDbCommand(mysql, myconnection2)

            Try
                mywriter.Connection.Open()
                mywriter.ExecuteNonQuery()
                mywriter.Connection.Close()

                refresh_grid()
                clear_fields()

            Catch ex As Exception

                Beep()
                MsgBox("There is a mistake in the data you entered, as shown below" & vbCrLf & vbCrLf & ex.Message)

                mywriter.Connection.Close()

            End Try

        End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click

        frm_staff_a164854.Show()
        Me.Hide()

    End Sub

    Private Sub pic_home_MouseClick(sender As Object, e As MouseEventArgs) Handles pic_home.MouseClick

        frm_mainmenu_a164854.Show()
        Me.Hide()
    End Sub
End Class