﻿Public Class frm_products_a164854

    Dim current_productid As String

    Private Sub frm_products_a164854_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        refresh_grid()
        get_current_id()
    End Sub

    Public Sub refresh_grid()

        Dim mysql As String = "SELECT * FROM TBL_PRODUCTS_A164854"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_products.DataSource = mydatatable

    End Sub

    Private Sub get_current_id()

        Dim current_row As Integer = grd_products.CurrentRow.Index
        current_productid = grd_products(0, current_row).Value

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click


        frm_mainmenu_a164854.Show()
        Me.Close()

    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click


        frm_insertproducts_a164854.Show()
        Me.Close()

    End Sub

    Private Sub btn_updatedelete_Click(sender As Object, e As EventArgs) Handles btn_updatedelete.Click


        frm_updateproducts_a164854.Show()
        Me.Close()

    End Sub


End Class