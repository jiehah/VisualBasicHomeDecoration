﻿Public Class frm_mainmenu_a164854
    Private Sub frm_mainmenu_a164854_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lbl_date.Text = Date.Now

        lbl_welcome.Text = "Welcome to DECO D'HOME SHOP System"
    End Sub

    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        End
    End Sub

    Private Sub btn_products_Click(sender As Object, e As EventArgs) Handles btn_products.Click

        frm_products_a164854.Show()
        Me.Hide()

    End Sub

    Private Sub btn_customers_Click(sender As Object, e As EventArgs) Handles btn_customers.Click

        frm_customers_a164854.Show()
        Me.Hide()
    End Sub

    Private Sub btn_orders_Click(sender As Object, e As EventArgs) Handles btn_orders.Click

        frm_makeorder_a164854.Show()
        Me.Hide()

    End Sub

    Private Sub btn_staff_Click(sender As Object, e As EventArgs) Handles btn_staff.Click

        frm_staff_a164854.Show()
        Me.Hide()

    End Sub

    Private Sub btn_productdetails_Click(sender As Object, e As EventArgs) Handles btn_productdetails.Click

        frm_productdetails_a164854.Show()
        Me.Hide()

    End Sub

End Class
