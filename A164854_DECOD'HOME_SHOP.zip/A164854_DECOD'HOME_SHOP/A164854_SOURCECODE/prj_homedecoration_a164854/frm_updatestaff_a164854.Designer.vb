﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_updatestaff_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_updatestaff_a164854))
        Me.btn_delete = New System.Windows.Forms.Button()
        Me.txt_phoneno = New System.Windows.Forms.TextBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.lbl_title4 = New System.Windows.Forms.Label()
        Me.lbl_title3 = New System.Windows.Forms.Label()
        Me.lbl_title2 = New System.Windows.Forms.Label()
        Me.lbl_title1 = New System.Windows.Forms.Label()
        Me.btn_update = New System.Windows.Forms.Button()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.grd_staff = New System.Windows.Forms.DataGridView()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.pic_home = New System.Windows.Forms.PictureBox()
        CType(Me.grd_staff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_delete
        '
        Me.btn_delete.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btn_delete.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delete.Location = New System.Drawing.Point(301, 574)
        Me.btn_delete.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_delete.Name = "btn_delete"
        Me.btn_delete.Size = New System.Drawing.Size(96, 34)
        Me.btn_delete.TabIndex = 70
        Me.btn_delete.Text = "DELETE"
        Me.btn_delete.UseVisualStyleBackColor = False
        '
        'txt_phoneno
        '
        Me.txt_phoneno.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_phoneno.Location = New System.Drawing.Point(158, 412)
        Me.txt_phoneno.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_phoneno.Name = "txt_phoneno"
        Me.txt_phoneno.Size = New System.Drawing.Size(200, 29)
        Me.txt_phoneno.TabIndex = 69
        '
        'txt_address
        '
        Me.txt_address.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_address.Location = New System.Drawing.Point(158, 453)
        Me.txt_address.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_address.Multiline = True
        Me.txt_address.Name = "txt_address"
        Me.txt_address.Size = New System.Drawing.Size(326, 92)
        Me.txt_address.TabIndex = 68
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(158, 373)
        Me.txt_name.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(326, 29)
        Me.txt_name.TabIndex = 67
        '
        'lbl_title4
        '
        Me.lbl_title4.AutoSize = True
        Me.lbl_title4.BackColor = System.Drawing.Color.PaleTurquoise
        Me.lbl_title4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title4.Location = New System.Drawing.Point(39, 412)
        Me.lbl_title4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title4.Name = "lbl_title4"
        Me.lbl_title4.Size = New System.Drawing.Size(117, 24)
        Me.lbl_title4.TabIndex = 66
        Me.lbl_title4.Text = "PHONE NO:"
        '
        'lbl_title3
        '
        Me.lbl_title3.AutoSize = True
        Me.lbl_title3.BackColor = System.Drawing.Color.PaleTurquoise
        Me.lbl_title3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title3.Location = New System.Drawing.Point(52, 453)
        Me.lbl_title3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title3.Name = "lbl_title3"
        Me.lbl_title3.Size = New System.Drawing.Size(104, 24)
        Me.lbl_title3.TabIndex = 65
        Me.lbl_title3.Text = "ADDRESS:"
        '
        'lbl_title2
        '
        Me.lbl_title2.AutoSize = True
        Me.lbl_title2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.lbl_title2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title2.Location = New System.Drawing.Point(80, 373)
        Me.lbl_title2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title2.Name = "lbl_title2"
        Me.lbl_title2.Size = New System.Drawing.Size(76, 24)
        Me.lbl_title2.TabIndex = 64
        Me.lbl_title2.Text = " NAME:"
        '
        'lbl_title1
        '
        Me.lbl_title1.AutoSize = True
        Me.lbl_title1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.lbl_title1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title1.Location = New System.Drawing.Point(124, 334)
        Me.lbl_title1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title1.Name = "lbl_title1"
        Me.lbl_title1.Size = New System.Drawing.Size(32, 24)
        Me.lbl_title1.TabIndex = 63
        Me.lbl_title1.Text = "ID:"
        '
        'btn_update
        '
        Me.btn_update.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btn_update.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update.Location = New System.Drawing.Point(168, 574)
        Me.btn_update.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_update.Name = "btn_update"
        Me.btn_update.Size = New System.Drawing.Size(96, 34)
        Me.btn_update.TabIndex = 62
        Me.btn_update.Text = "UPDATE"
        Me.btn_update.UseVisualStyleBackColor = False
        '
        'txt_id
        '
        Me.txt_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_id.Location = New System.Drawing.Point(158, 334)
        Me.txt_id.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.Size = New System.Drawing.Size(123, 29)
        Me.txt_id.TabIndex = 61
        '
        'grd_staff
        '
        Me.grd_staff.BackgroundColor = System.Drawing.Color.PowderBlue
        Me.grd_staff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_staff.Location = New System.Drawing.Point(6, 60)
        Me.grd_staff.Margin = New System.Windows.Forms.Padding(1)
        Me.grd_staff.Name = "grd_staff"
        Me.grd_staff.RowTemplate.Height = 40
        Me.grd_staff.Size = New System.Drawing.Size(596, 246)
        Me.grd_staff.TabIndex = 60
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.PowderBlue
        Me.lbl_title.Font = New System.Drawing.Font("Matura MT Script Capitals", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(78, 9)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(445, 36)
        Me.lbl_title.TabIndex = 59
        Me.lbl_title.Text = "UPDATE NEW STAFF"
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Aquamarine
        Me.btn_back.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(506, 573)
        Me.btn_back.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(96, 34)
        Me.btn_back.TabIndex = 71
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'pic_home
        '
        Me.pic_home.BackColor = System.Drawing.Color.MediumSpringGreen
        Me.pic_home.BackgroundImage = CType(resources.GetObject("pic_home.BackgroundImage"), System.Drawing.Image)
        Me.pic_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pic_home.Location = New System.Drawing.Point(12, 555)
        Me.pic_home.Name = "pic_home"
        Me.pic_home.Size = New System.Drawing.Size(54, 50)
        Me.pic_home.TabIndex = 72
        Me.pic_home.TabStop = False
        '
        'frm_updatestaff_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(612, 617)
        Me.Controls.Add(Me.pic_home)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_delete)
        Me.Controls.Add(Me.txt_phoneno)
        Me.Controls.Add(Me.txt_address)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.lbl_title4)
        Me.Controls.Add(Me.lbl_title3)
        Me.Controls.Add(Me.lbl_title2)
        Me.Controls.Add(Me.lbl_title1)
        Me.Controls.Add(Me.btn_update)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.grd_staff)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_updatestaff_a164854"
        Me.Text = "frm_updatestaff_a164854"
        CType(Me.grd_staff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_delete As Button
    Friend WithEvents txt_phoneno As TextBox
    Friend WithEvents txt_address As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents lbl_title4 As Label
    Friend WithEvents lbl_title3 As Label
    Friend WithEvents lbl_title2 As Label
    Friend WithEvents lbl_title1 As Label
    Friend WithEvents btn_update As Button
    Friend WithEvents txt_id As TextBox
    Friend WithEvents grd_staff As DataGridView
    Friend WithEvents lbl_title As Label
    Friend WithEvents btn_back As Button
    Friend WithEvents pic_home As PictureBox
End Class
