﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_insertstaff_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_insertstaff_a164854))
        Me.txt_phoneno = New System.Windows.Forms.TextBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.lbl_title4 = New System.Windows.Forms.Label()
        Me.lbl_title3 = New System.Windows.Forms.Label()
        Me.lbl_title2 = New System.Windows.Forms.Label()
        Me.lbl_title1 = New System.Windows.Forms.Label()
        Me.btn_insert = New System.Windows.Forms.Button()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.grd_staff = New System.Windows.Forms.DataGridView()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.pic_home = New System.Windows.Forms.PictureBox()
        CType(Me.grd_staff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt_phoneno
        '
        Me.txt_phoneno.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_phoneno.Location = New System.Drawing.Point(218, 410)
        Me.txt_phoneno.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_phoneno.Name = "txt_phoneno"
        Me.txt_phoneno.Size = New System.Drawing.Size(200, 29)
        Me.txt_phoneno.TabIndex = 46
        '
        'txt_address
        '
        Me.txt_address.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_address.Location = New System.Drawing.Point(218, 448)
        Me.txt_address.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_address.Multiline = True
        Me.txt_address.Name = "txt_address"
        Me.txt_address.Size = New System.Drawing.Size(326, 92)
        Me.txt_address.TabIndex = 45
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(218, 371)
        Me.txt_name.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(326, 29)
        Me.txt_name.TabIndex = 44
        '
        'lbl_title4
        '
        Me.lbl_title4.AutoSize = True
        Me.lbl_title4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title4.Location = New System.Drawing.Point(99, 410)
        Me.lbl_title4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title4.Name = "lbl_title4"
        Me.lbl_title4.Size = New System.Drawing.Size(117, 24)
        Me.lbl_title4.TabIndex = 43
        Me.lbl_title4.Text = "PHONE NO:"
        '
        'lbl_title3
        '
        Me.lbl_title3.AutoSize = True
        Me.lbl_title3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title3.Location = New System.Drawing.Point(112, 448)
        Me.lbl_title3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title3.Name = "lbl_title3"
        Me.lbl_title3.Size = New System.Drawing.Size(104, 24)
        Me.lbl_title3.TabIndex = 42
        Me.lbl_title3.Text = "ADDRESS:"
        '
        'lbl_title2
        '
        Me.lbl_title2.AutoSize = True
        Me.lbl_title2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title2.Location = New System.Drawing.Point(140, 371)
        Me.lbl_title2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title2.Name = "lbl_title2"
        Me.lbl_title2.Size = New System.Drawing.Size(76, 24)
        Me.lbl_title2.TabIndex = 41
        Me.lbl_title2.Text = " NAME:"
        '
        'lbl_title1
        '
        Me.lbl_title1.AutoSize = True
        Me.lbl_title1.BackColor = System.Drawing.Color.MistyRose
        Me.lbl_title1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title1.Location = New System.Drawing.Point(184, 332)
        Me.lbl_title1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title1.Name = "lbl_title1"
        Me.lbl_title1.Size = New System.Drawing.Size(32, 24)
        Me.lbl_title1.TabIndex = 40
        Me.lbl_title1.Text = "ID:"
        '
        'btn_insert
        '
        Me.btn_insert.BackColor = System.Drawing.Color.HotPink
        Me.btn_insert.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert.Location = New System.Drawing.Point(292, 561)
        Me.btn_insert.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_insert.Name = "btn_insert"
        Me.btn_insert.Size = New System.Drawing.Size(87, 34)
        Me.btn_insert.TabIndex = 39
        Me.btn_insert.Text = "INSERT"
        Me.btn_insert.UseVisualStyleBackColor = False
        '
        'txt_id
        '
        Me.txt_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_id.Location = New System.Drawing.Point(218, 332)
        Me.txt_id.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.Size = New System.Drawing.Size(123, 29)
        Me.txt_id.TabIndex = 38
        '
        'grd_staff
        '
        Me.grd_staff.BackgroundColor = System.Drawing.Color.LightPink
        Me.grd_staff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_staff.Location = New System.Drawing.Point(27, 66)
        Me.grd_staff.Margin = New System.Windows.Forms.Padding(1)
        Me.grd_staff.Name = "grd_staff"
        Me.grd_staff.RowTemplate.Height = 40
        Me.grd_staff.Size = New System.Drawing.Size(629, 246)
        Me.grd_staff.TabIndex = 37
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.MistyRose
        Me.lbl_title.Font = New System.Drawing.Font("Matura MT Script Capitals", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(150, 9)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(381, 36)
        Me.lbl_title.TabIndex = 36
        Me.lbl_title.Text = "ADD NEW STAFF"
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.HotPink
        Me.btn_back.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(569, 561)
        Me.btn_back.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(87, 34)
        Me.btn_back.TabIndex = 47
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'pic_home
        '
        Me.pic_home.BackColor = System.Drawing.Color.Pink
        Me.pic_home.BackgroundImage = CType(resources.GetObject("pic_home.BackgroundImage"), System.Drawing.Image)
        Me.pic_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pic_home.Location = New System.Drawing.Point(27, 545)
        Me.pic_home.Name = "pic_home"
        Me.pic_home.Size = New System.Drawing.Size(54, 50)
        Me.pic_home.TabIndex = 73
        Me.pic_home.TabStop = False
        '
        'frm_insertstaff_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MistyRose
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(681, 605)
        Me.Controls.Add(Me.pic_home)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.txt_phoneno)
        Me.Controls.Add(Me.txt_address)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.lbl_title4)
        Me.Controls.Add(Me.lbl_title3)
        Me.Controls.Add(Me.lbl_title2)
        Me.Controls.Add(Me.lbl_title1)
        Me.Controls.Add(Me.btn_insert)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.grd_staff)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_insertstaff_a164854"
        Me.Text = "frm_insertstaff_a164854"
        CType(Me.grd_staff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_phoneno As TextBox
    Friend WithEvents txt_address As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents lbl_title4 As Label
    Friend WithEvents lbl_title3 As Label
    Friend WithEvents lbl_title2 As Label
    Friend WithEvents lbl_title1 As Label
    Friend WithEvents btn_insert As Button
    Friend WithEvents txt_id As TextBox
    Friend WithEvents grd_staff As DataGridView
    Friend WithEvents lbl_title As Label
    Friend WithEvents btn_back As Button
    Friend WithEvents pic_home As PictureBox
End Class
