﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_mainmenu_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_mainmenu_a164854))
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_welcome = New System.Windows.Forms.Label()
        Me.btn_products = New System.Windows.Forms.Button()
        Me.btn_customers = New System.Windows.Forms.Button()
        Me.btn_staff = New System.Windows.Forms.Button()
        Me.btn_orders = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.btn_productdetails = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Violet
        Me.lbl_title.Font = New System.Drawing.Font("Comic Sans MS", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(27, 9)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(678, 135)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "MAIN MENU"
        '
        'lbl_welcome
        '
        Me.lbl_welcome.AutoSize = True
        Me.lbl_welcome.BackColor = System.Drawing.Color.Thistle
        Me.lbl_welcome.Font = New System.Drawing.Font("Tw Cen MT", 27.9!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_welcome.Location = New System.Drawing.Point(42, 164)
        Me.lbl_welcome.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_welcome.Name = "lbl_welcome"
        Me.lbl_welcome.Size = New System.Drawing.Size(119, 44)
        Me.lbl_welcome.TabIndex = 1
        Me.lbl_welcome.Text = "Label1"
        '
        'btn_products
        '
        Me.btn_products.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_products.Font = New System.Drawing.Font("Maiandra GD", 20.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_products.Location = New System.Drawing.Point(141, 247)
        Me.btn_products.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_products.Name = "btn_products"
        Me.btn_products.Size = New System.Drawing.Size(174, 44)
        Me.btn_products.TabIndex = 2
        Me.btn_products.Text = "PRODUCTS"
        Me.btn_products.UseVisualStyleBackColor = False
        '
        'btn_customers
        '
        Me.btn_customers.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_customers.Font = New System.Drawing.Font("Maiandra GD", 20.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customers.Location = New System.Drawing.Point(141, 320)
        Me.btn_customers.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_customers.Name = "btn_customers"
        Me.btn_customers.Size = New System.Drawing.Size(174, 44)
        Me.btn_customers.TabIndex = 3
        Me.btn_customers.Text = "CUSTOMERS"
        Me.btn_customers.UseVisualStyleBackColor = False
        '
        'btn_staff
        '
        Me.btn_staff.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_staff.Font = New System.Drawing.Font("Maiandra GD", 20.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staff.Location = New System.Drawing.Point(380, 247)
        Me.btn_staff.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_staff.Name = "btn_staff"
        Me.btn_staff.Size = New System.Drawing.Size(174, 38)
        Me.btn_staff.TabIndex = 4
        Me.btn_staff.Text = "STAFF"
        Me.btn_staff.UseVisualStyleBackColor = False
        '
        'btn_orders
        '
        Me.btn_orders.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_orders.Font = New System.Drawing.Font("Maiandra GD", 20.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_orders.Location = New System.Drawing.Point(380, 326)
        Me.btn_orders.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_orders.Name = "btn_orders"
        Me.btn_orders.Size = New System.Drawing.Size(174, 38)
        Me.btn_orders.TabIndex = 5
        Me.btn_orders.Text = "ORDERS"
        Me.btn_orders.UseVisualStyleBackColor = False
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btn_exit.Font = New System.Drawing.Font("Maiandra GD", 20.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_exit.Location = New System.Drawing.Point(219, 510)
        Me.btn_exit.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(262, 37)
        Me.btn_exit.TabIndex = 6
        Me.btn_exit.Text = "EXIT PROGRAM"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.BackColor = System.Drawing.Color.PaleVioletRed
        Me.lbl_date.Font = New System.Drawing.Font("Century Schoolbook", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.Location = New System.Drawing.Point(534, 580)
        Me.lbl_date.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(60, 20)
        Me.lbl_date.TabIndex = 7
        Me.lbl_date.Text = "Label1"
        '
        'btn_productdetails
        '
        Me.btn_productdetails.BackColor = System.Drawing.Color.Thistle
        Me.btn_productdetails.Font = New System.Drawing.Font("Trebuchet MS", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_productdetails.Location = New System.Drawing.Point(259, 398)
        Me.btn_productdetails.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_productdetails.Name = "btn_productdetails"
        Me.btn_productdetails.Size = New System.Drawing.Size(177, 82)
        Me.btn_productdetails.TabIndex = 11
        Me.btn_productdetails.Text = "PRODUCT DETAILS"
        Me.btn_productdetails.UseVisualStyleBackColor = False
        '
        'frm_mainmenu_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Pink
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(732, 623)
        Me.Controls.Add(Me.btn_productdetails)
        Me.Controls.Add(Me.lbl_date)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_orders)
        Me.Controls.Add(Me.btn_staff)
        Me.Controls.Add(Me.btn_customers)
        Me.Controls.Add(Me.btn_products)
        Me.Controls.Add(Me.lbl_welcome)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "frm_mainmenu_a164854"
        Me.Text = "frm_mainmenu_a164854"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents lbl_welcome As Label
    Friend WithEvents btn_products As Button
    Friend WithEvents btn_customers As Button
    Friend WithEvents btn_staff As Button
    Friend WithEvents btn_orders As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents lbl_date As Label
    Friend WithEvents btn_productdetails As Button
End Class
