﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_order_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_order_a164854))
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lbl_id = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lbl_total = New System.Windows.Forms.Label()
        Me.labelprice = New System.Windows.Forms.Label()
        Me.tb_sttaffid = New System.Windows.Forms.TextBox()
        Me.tb_custid = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmb_id = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.order = New System.Windows.Forms.DataGridView()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pic_home = New System.Windows.Forms.PictureBox()
        CType(Me.order, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(182, 322)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(400, 17)
        Me.Label9.TabIndex = 45
        Me.Label9.Text = "Thank You for trusting DECO D'HOME Shop services! "
        '
        'lbl_id
        '
        Me.lbl_id.AutoSize = True
        Me.lbl_id.BackColor = System.Drawing.Color.Salmon
        Me.lbl_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_id.Location = New System.Drawing.Point(606, 161)
        Me.lbl_id.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_id.Name = "lbl_id"
        Me.lbl_id.Size = New System.Drawing.Size(38, 29)
        Me.lbl_id.TabIndex = 44
        Me.lbl_id.Text = "ID"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(608, 143)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(94, 18)
        Me.Label10.TabIndex = 43
        Me.Label10.Text = "ORDER ID:"
        '
        'lbl_total
        '
        Me.lbl_total.AutoSize = True
        Me.lbl_total.BackColor = System.Drawing.Color.Salmon
        Me.lbl_total.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_total.Location = New System.Drawing.Point(606, 245)
        Me.lbl_total.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_total.Name = "lbl_total"
        Me.lbl_total.Size = New System.Drawing.Size(97, 29)
        Me.lbl_total.TabIndex = 42
        Me.lbl_total.Text = "TOTAL"
        '
        'labelprice
        '
        Me.labelprice.AutoSize = True
        Me.labelprice.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.labelprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelprice.Location = New System.Drawing.Point(608, 227)
        Me.labelprice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.labelprice.Name = "labelprice"
        Me.labelprice.Size = New System.Drawing.Size(63, 18)
        Me.labelprice.TabIndex = 41
        Me.labelprice.Text = "PRICE:"
        '
        'tb_sttaffid
        '
        Me.tb_sttaffid.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.tb_sttaffid.Location = New System.Drawing.Point(38, 247)
        Me.tb_sttaffid.Margin = New System.Windows.Forms.Padding(2)
        Me.tb_sttaffid.Name = "tb_sttaffid"
        Me.tb_sttaffid.ReadOnly = True
        Me.tb_sttaffid.Size = New System.Drawing.Size(118, 20)
        Me.tb_sttaffid.TabIndex = 40
        '
        'tb_custid
        '
        Me.tb_custid.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.tb_custid.Location = New System.Drawing.Point(38, 197)
        Me.tb_custid.Margin = New System.Windows.Forms.Padding(2)
        Me.tb_custid.Name = "tb_custid"
        Me.tb_custid.ReadOnly = True
        Me.tb_custid.Size = New System.Drawing.Size(118, 20)
        Me.tb_custid.TabIndex = 39
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Salmon
        Me.Label8.Location = New System.Drawing.Point(36, 232)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Staff ID"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Salmon
        Me.Label7.Location = New System.Drawing.Point(36, 182)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 13)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Customer ID"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Salmon
        Me.Label6.Location = New System.Drawing.Point(36, 125)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Order ID"
        '
        'cmb_id
        '
        Me.cmb_id.FormattingEnabled = True
        Me.cmb_id.Location = New System.Drawing.Point(36, 140)
        Me.cmb_id.Margin = New System.Windows.Forms.Padding(2)
        Me.cmb_id.Name = "cmb_id"
        Me.cmb_id.Size = New System.Drawing.Size(121, 21)
        Me.cmb_id.TabIndex = 35
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Salmon
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(17, 369)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(70, 30)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "BACK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'order
        '
        Me.order.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.order.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.order.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.order.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.order.Location = New System.Drawing.Point(173, 143)
        Me.order.Margin = New System.Windows.Forms.Padding(2)
        Me.order.Name = "order"
        Me.order.ReadOnly = True
        Me.order.RowTemplate.Height = 28
        Me.order.Size = New System.Drawing.Size(422, 177)
        Me.order.TabIndex = 26
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Perpetua Titling MT", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 26)
        Me.Label11.TabIndex = 46
        Me.Label11.Text = "COPY"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.SeaShell
        Me.Label12.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(332, 9)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 29)
        Me.Label12.TabIndex = 47
        Me.Label12.Text = "INVOICE"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MistyRose
        Me.Label1.Font = New System.Drawing.Font("Segoe Script", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(141, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(480, 42)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "DECO D'HOME SHOP SDN BHD" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.LightSalmon
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(286, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(195, 39)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "               LOT 2, JALAN PJU, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "               MUTIARA BARAT," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "47800 PETALING " &
    "JAYA, SELANGOR"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.MistyRose
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(272, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(220, 13)
        Me.Label3.TabIndex = 50
        Me.Label3.Text = "TEL: 012-2213343      FAX: 03-4563210" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'pic_home
        '
        Me.pic_home.BackColor = System.Drawing.Color.Salmon
        Me.pic_home.BackgroundImage = CType(resources.GetObject("pic_home.BackgroundImage"), System.Drawing.Image)
        Me.pic_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pic_home.Location = New System.Drawing.Point(682, 349)
        Me.pic_home.Name = "pic_home"
        Me.pic_home.Size = New System.Drawing.Size(54, 50)
        Me.pic_home.TabIndex = 74
        Me.pic_home.TabStop = False
        '
        'frm_order_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(748, 404)
        Me.Controls.Add(Me.pic_home)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lbl_id)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lbl_total)
        Me.Controls.Add(Me.labelprice)
        Me.Controls.Add(Me.tb_sttaffid)
        Me.Controls.Add(Me.tb_custid)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cmb_id)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.order)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_order_a164854"
        Me.Text = "frm_order_a164854"
        CType(Me.order, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents lbl_id As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lbl_total As Label
    Friend WithEvents labelprice As Label
    Friend WithEvents tb_sttaffid As TextBox
    Friend WithEvents tb_custid As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cmb_id As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents order As DataGridView
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents pic_home As PictureBox
End Class
