﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_insertcustomer_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_insertcustomer_a164854))
        Me.lbl_title4 = New System.Windows.Forms.Label()
        Me.lbl_title3 = New System.Windows.Forms.Label()
        Me.lbl_title2 = New System.Windows.Forms.Label()
        Me.lbl_title1 = New System.Windows.Forms.Label()
        Me.btn_insert = New System.Windows.Forms.Button()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.grd_customer = New System.Windows.Forms.DataGridView()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.txt_address = New System.Windows.Forms.TextBox()
        Me.txt_phoneno = New System.Windows.Forms.TextBox()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.pic_home = New System.Windows.Forms.PictureBox()
        CType(Me.grd_customer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_title4
        '
        Me.lbl_title4.AutoSize = True
        Me.lbl_title4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title4.Location = New System.Drawing.Point(67, 521)
        Me.lbl_title4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title4.Name = "lbl_title4"
        Me.lbl_title4.Size = New System.Drawing.Size(117, 24)
        Me.lbl_title4.TabIndex = 32
        Me.lbl_title4.Text = "PHONE NO:"
        '
        'lbl_title3
        '
        Me.lbl_title3.AutoSize = True
        Me.lbl_title3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title3.Location = New System.Drawing.Point(80, 418)
        Me.lbl_title3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title3.Name = "lbl_title3"
        Me.lbl_title3.Size = New System.Drawing.Size(104, 24)
        Me.lbl_title3.TabIndex = 31
        Me.lbl_title3.Text = "ADDRESS:"
        '
        'lbl_title2
        '
        Me.lbl_title2.AutoSize = True
        Me.lbl_title2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title2.Location = New System.Drawing.Point(108, 376)
        Me.lbl_title2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title2.Name = "lbl_title2"
        Me.lbl_title2.Size = New System.Drawing.Size(76, 24)
        Me.lbl_title2.TabIndex = 30
        Me.lbl_title2.Text = " NAME:"
        '
        'lbl_title1
        '
        Me.lbl_title1.AutoSize = True
        Me.lbl_title1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title1.Location = New System.Drawing.Point(152, 337)
        Me.lbl_title1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title1.Name = "lbl_title1"
        Me.lbl_title1.Size = New System.Drawing.Size(32, 24)
        Me.lbl_title1.TabIndex = 29
        Me.lbl_title1.Text = "ID:"
        '
        'btn_insert
        '
        Me.btn_insert.BackColor = System.Drawing.Color.MediumSpringGreen
        Me.btn_insert.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insert.Location = New System.Drawing.Point(251, 563)
        Me.btn_insert.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_insert.Name = "btn_insert"
        Me.btn_insert.Size = New System.Drawing.Size(87, 34)
        Me.btn_insert.TabIndex = 28
        Me.btn_insert.Text = "INSERT"
        Me.btn_insert.UseVisualStyleBackColor = False
        '
        'txt_id
        '
        Me.txt_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_id.Location = New System.Drawing.Point(186, 337)
        Me.txt_id.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.Size = New System.Drawing.Size(123, 29)
        Me.txt_id.TabIndex = 24
        '
        'grd_customer
        '
        Me.grd_customer.BackgroundColor = System.Drawing.Color.Aquamarine
        Me.grd_customer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_customer.Location = New System.Drawing.Point(10, 70)
        Me.grd_customer.Margin = New System.Windows.Forms.Padding(1)
        Me.grd_customer.Name = "grd_customer"
        Me.grd_customer.RowTemplate.Height = 40
        Me.grd_customer.Size = New System.Drawing.Size(596, 246)
        Me.grd_customer.TabIndex = 23
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Turquoise
        Me.lbl_title.Font = New System.Drawing.Font("Matura MT Script Capitals", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(77, 19)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(452, 36)
        Me.lbl_title.TabIndex = 22
        Me.lbl_title.Text = "ADD NEW CUSTOMER"
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(186, 376)
        Me.txt_name.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(326, 29)
        Me.txt_name.TabIndex = 33
        '
        'txt_address
        '
        Me.txt_address.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_address.Location = New System.Drawing.Point(186, 415)
        Me.txt_address.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_address.Multiline = True
        Me.txt_address.Name = "txt_address"
        Me.txt_address.Size = New System.Drawing.Size(326, 92)
        Me.txt_address.TabIndex = 34
        '
        'txt_phoneno
        '
        Me.txt_phoneno.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_phoneno.Location = New System.Drawing.Point(186, 521)
        Me.txt_phoneno.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_phoneno.Name = "txt_phoneno"
        Me.txt_phoneno.Size = New System.Drawing.Size(200, 29)
        Me.txt_phoneno.TabIndex = 35
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.MediumSpringGreen
        Me.btn_back.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(527, 563)
        Me.btn_back.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(79, 36)
        Me.btn_back.TabIndex = 36
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'pic_home
        '
        Me.pic_home.BackColor = System.Drawing.Color.MediumSpringGreen
        Me.pic_home.BackgroundImage = CType(resources.GetObject("pic_home.BackgroundImage"), System.Drawing.Image)
        Me.pic_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pic_home.Location = New System.Drawing.Point(10, 549)
        Me.pic_home.Name = "pic_home"
        Me.pic_home.Size = New System.Drawing.Size(54, 50)
        Me.pic_home.TabIndex = 75
        Me.pic_home.TabStop = False
        '
        'frm_insertcustomer_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Turquoise
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(616, 605)
        Me.Controls.Add(Me.pic_home)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.txt_phoneno)
        Me.Controls.Add(Me.txt_address)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.lbl_title4)
        Me.Controls.Add(Me.lbl_title3)
        Me.Controls.Add(Me.lbl_title2)
        Me.Controls.Add(Me.lbl_title1)
        Me.Controls.Add(Me.btn_insert)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.grd_customer)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_insertcustomer_a164854"
        Me.Text = "frm_insertcustomer_a164854"
        CType(Me.grd_customer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title4 As Label
    Friend WithEvents lbl_title3 As Label
    Friend WithEvents lbl_title2 As Label
    Friend WithEvents lbl_title1 As Label
    Friend WithEvents btn_insert As Button
    Friend WithEvents txt_id As TextBox
    Friend WithEvents grd_customer As DataGridView
    Friend WithEvents lbl_title As Label
    Friend WithEvents txt_name As TextBox
    Friend WithEvents txt_address As TextBox
    Friend WithEvents txt_phoneno As TextBox
    Friend WithEvents btn_back As Button
    Friend WithEvents pic_home As PictureBox
End Class
