﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_updateproducts_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_updateproducts_a164854))
        Me.txt_desc = New System.Windows.Forms.TextBox()
        Me.txt_type = New System.Windows.Forms.TextBox()
        Me.txt_size = New System.Windows.Forms.TextBox()
        Me.lbl_size = New System.Windows.Forms.Label()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.lbl_description = New System.Windows.Forms.Label()
        Me.lbl_type = New System.Windows.Forms.Label()
        Me.lbl_title4 = New System.Windows.Forms.Label()
        Me.lbl_title3 = New System.Windows.Forms.Label()
        Me.lbl_title2 = New System.Windows.Forms.Label()
        Me.lbl_title1 = New System.Windows.Forms.Label()
        Me.txt_manufacturer = New System.Windows.Forms.TextBox()
        Me.grd_product = New System.Windows.Forms.DataGridView()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.btn_delete = New System.Windows.Forms.Button()
        Me.btn_update = New System.Windows.Forms.Button()
        Me.pic_home = New System.Windows.Forms.PictureBox()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.grd_product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt_desc
        '
        Me.txt_desc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_desc.Location = New System.Drawing.Point(395, 444)
        Me.txt_desc.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_desc.Multiline = True
        Me.txt_desc.Name = "txt_desc"
        Me.txt_desc.Size = New System.Drawing.Size(322, 119)
        Me.txt_desc.TabIndex = 64
        '
        'txt_type
        '
        Me.txt_type.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_type.Location = New System.Drawing.Point(203, 578)
        Me.txt_type.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_type.Multiline = True
        Me.txt_type.Name = "txt_type"
        Me.txt_type.Size = New System.Drawing.Size(172, 67)
        Me.txt_type.TabIndex = 63
        '
        'txt_size
        '
        Me.txt_size.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_size.Location = New System.Drawing.Point(203, 539)
        Me.txt_size.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_size.Multiline = True
        Me.txt_size.Name = "txt_size"
        Me.txt_size.Size = New System.Drawing.Size(172, 24)
        Me.txt_size.TabIndex = 62
        '
        'lbl_size
        '
        Me.lbl_size.AutoSize = True
        Me.lbl_size.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_size.Location = New System.Drawing.Point(128, 539)
        Me.lbl_size.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_size.Name = "lbl_size"
        Me.lbl_size.Size = New System.Drawing.Size(56, 24)
        Me.lbl_size.TabIndex = 61
        Me.lbl_size.Text = "SIZE:"
        '
        'txt_price
        '
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(203, 497)
        Me.txt_price.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_price.Multiline = True
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(172, 24)
        Me.txt_price.TabIndex = 60
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(203, 454)
        Me.txt_name.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_name.Multiline = True
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(172, 24)
        Me.txt_name.TabIndex = 59
        '
        'txt_id
        '
        Me.txt_id.BackColor = System.Drawing.SystemColors.Window
        Me.txt_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_id.Location = New System.Drawing.Point(203, 410)
        Me.txt_id.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_id.Multiline = True
        Me.txt_id.Name = "txt_id"
        Me.txt_id.ReadOnly = True
        Me.txt_id.Size = New System.Drawing.Size(172, 24)
        Me.txt_id.TabIndex = 58
        '
        'lbl_description
        '
        Me.lbl_description.AutoSize = True
        Me.lbl_description.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_description.Location = New System.Drawing.Point(391, 410)
        Me.lbl_description.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_description.Name = "lbl_description"
        Me.lbl_description.Size = New System.Drawing.Size(140, 24)
        Me.lbl_description.TabIndex = 57
        Me.lbl_description.Text = "DESCRIPTION:"
        '
        'lbl_type
        '
        Me.lbl_type.AutoSize = True
        Me.lbl_type.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_type.Location = New System.Drawing.Point(120, 578)
        Me.lbl_type.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_type.Name = "lbl_type"
        Me.lbl_type.Size = New System.Drawing.Size(64, 24)
        Me.lbl_type.TabIndex = 56
        Me.lbl_type.Text = "TYPE:"
        '
        'lbl_title4
        '
        Me.lbl_title4.AutoSize = True
        Me.lbl_title4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title4.Location = New System.Drawing.Point(421, 578)
        Me.lbl_title4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title4.Name = "lbl_title4"
        Me.lbl_title4.Size = New System.Drawing.Size(93, 24)
        Me.lbl_title4.TabIndex = 55
        Me.lbl_title4.Text = "MADE IN:"
        '
        'lbl_title3
        '
        Me.lbl_title3.AutoSize = True
        Me.lbl_title3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title3.Location = New System.Drawing.Point(114, 497)
        Me.lbl_title3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title3.Name = "lbl_title3"
        Me.lbl_title3.Size = New System.Drawing.Size(70, 24)
        Me.lbl_title3.TabIndex = 54
        Me.lbl_title3.Text = "PRICE:"
        '
        'lbl_title2
        '
        Me.lbl_title2.AutoSize = True
        Me.lbl_title2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title2.Location = New System.Drawing.Point(17, 454)
        Me.lbl_title2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title2.Name = "lbl_title2"
        Me.lbl_title2.Size = New System.Drawing.Size(167, 24)
        Me.lbl_title2.TabIndex = 53
        Me.lbl_title2.Text = "PRODUCT NAME:"
        '
        'lbl_title1
        '
        Me.lbl_title1.AutoSize = True
        Me.lbl_title1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title1.Location = New System.Drawing.Point(56, 410)
        Me.lbl_title1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title1.Name = "lbl_title1"
        Me.lbl_title1.Size = New System.Drawing.Size(128, 24)
        Me.lbl_title1.TabIndex = 52
        Me.lbl_title1.Text = "PRODUCT ID:"
        '
        'txt_manufacturer
        '
        Me.txt_manufacturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_manufacturer.Location = New System.Drawing.Point(545, 578)
        Me.txt_manufacturer.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_manufacturer.Multiline = True
        Me.txt_manufacturer.Name = "txt_manufacturer"
        Me.txt_manufacturer.Size = New System.Drawing.Size(172, 24)
        Me.txt_manufacturer.TabIndex = 51
        '
        'grd_product
        '
        Me.grd_product.AllowUserToAddRows = False
        Me.grd_product.BackgroundColor = System.Drawing.Color.Linen
        Me.grd_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd_product.Location = New System.Drawing.Point(10, 57)
        Me.grd_product.Margin = New System.Windows.Forms.Padding(1)
        Me.grd_product.Name = "grd_product"
        Me.grd_product.ReadOnly = True
        Me.grd_product.RowTemplate.Height = 40
        Me.grd_product.Size = New System.Drawing.Size(719, 327)
        Me.grd_product.TabIndex = 50
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.SandyBrown
        Me.lbl_title.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(174, 9)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(357, 36)
        Me.lbl_title.TabIndex = 49
        Me.lbl_title.Text = "UPDATE PRODUCTS"
        '
        'btn_delete
        '
        Me.btn_delete.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_delete.Font = New System.Drawing.Font("Open Sans", 11.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delete.Location = New System.Drawing.Point(395, 659)
        Me.btn_delete.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_delete.Name = "btn_delete"
        Me.btn_delete.Size = New System.Drawing.Size(86, 37)
        Me.btn_delete.TabIndex = 66
        Me.btn_delete.Text = "DELETE"
        Me.btn_delete.UseVisualStyleBackColor = False
        '
        'btn_update
        '
        Me.btn_update.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_update.Font = New System.Drawing.Font("Open Sans", 11.1!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update.Location = New System.Drawing.Point(289, 659)
        Me.btn_update.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_update.Name = "btn_update"
        Me.btn_update.Size = New System.Drawing.Size(86, 37)
        Me.btn_update.TabIndex = 65
        Me.btn_update.Text = "UPDATE"
        Me.btn_update.UseVisualStyleBackColor = False
        '
        'pic_home
        '
        Me.pic_home.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.pic_home.BackgroundImage = CType(resources.GetObject("pic_home.BackgroundImage"), System.Drawing.Image)
        Me.pic_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pic_home.Location = New System.Drawing.Point(10, 643)
        Me.pic_home.Name = "pic_home"
        Me.pic_home.Size = New System.Drawing.Size(54, 50)
        Me.pic_home.TabIndex = 74
        Me.pic_home.TabStop = False
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.btn_back.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(621, 659)
        Me.btn_back.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(96, 34)
        Me.btn_back.TabIndex = 73
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_updateproducts_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(738, 697)
        Me.Controls.Add(Me.pic_home)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_delete)
        Me.Controls.Add(Me.btn_update)
        Me.Controls.Add(Me.txt_desc)
        Me.Controls.Add(Me.txt_type)
        Me.Controls.Add(Me.txt_size)
        Me.Controls.Add(Me.lbl_size)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.lbl_description)
        Me.Controls.Add(Me.lbl_type)
        Me.Controls.Add(Me.lbl_title4)
        Me.Controls.Add(Me.lbl_title3)
        Me.Controls.Add(Me.lbl_title2)
        Me.Controls.Add(Me.lbl_title1)
        Me.Controls.Add(Me.txt_manufacturer)
        Me.Controls.Add(Me.grd_product)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frm_updateproducts_a164854"
        Me.Text = "frm_updateproducts_a164854"
        CType(Me.grd_product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_home, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_desc As TextBox
    Friend WithEvents txt_type As TextBox
    Friend WithEvents txt_size As TextBox
    Friend WithEvents lbl_size As Label
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents txt_id As TextBox
    Friend WithEvents lbl_description As Label
    Friend WithEvents lbl_type As Label
    Friend WithEvents lbl_title4 As Label
    Friend WithEvents lbl_title3 As Label
    Friend WithEvents lbl_title2 As Label
    Friend WithEvents lbl_title1 As Label
    Friend WithEvents txt_manufacturer As TextBox
    Friend WithEvents grd_product As DataGridView
    Friend WithEvents lbl_title As Label
    Friend WithEvents btn_delete As Button
    Friend WithEvents btn_update As Button
    Friend WithEvents pic_home As PictureBox
    Friend WithEvents btn_back As Button
End Class
