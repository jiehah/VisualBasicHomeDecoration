﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_productdetails_a164854
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_productdetails_a164854))
        Me.pic_product = New System.Windows.Forms.PictureBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.txt_product_id = New System.Windows.Forms.TextBox()
        Me.lst_product_id = New System.Windows.Forms.ListBox()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.txt_type = New System.Windows.Forms.TextBox()
        Me.txt_size = New System.Windows.Forms.TextBox()
        Me.txt_manufacturer = New System.Windows.Forms.TextBox()
        Me.lbl_id = New System.Windows.Forms.Label()
        Me.lbl_name = New System.Windows.Forms.Label()
        Me.lbl_price = New System.Windows.Forms.Label()
        Me.lbl_size = New System.Windows.Forms.Label()
        Me.lbl_type = New System.Windows.Forms.Label()
        Me.lbl_manufacturer = New System.Windows.Forms.Label()
        Me.lbl_description = New System.Windows.Forms.Label()
        Me.txt_description = New System.Windows.Forms.TextBox()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic_product
        '
        Me.pic_product.BackColor = System.Drawing.Color.Wheat
        Me.pic_product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_product.Location = New System.Drawing.Point(350, 106)
        Me.pic_product.Margin = New System.Windows.Forms.Padding(1)
        Me.pic_product.Name = "pic_product"
        Me.pic_product.Size = New System.Drawing.Size(145, 214)
        Me.pic_product.TabIndex = 11
        Me.pic_product.TabStop = False
        '
        'txt_price
        '
        Me.txt_price.BackColor = System.Drawing.Color.MistyRose
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(201, 196)
        Me.txt_price.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(125, 26)
        Me.txt_price.TabIndex = 10
        '
        'txt_name
        '
        Me.txt_name.BackColor = System.Drawing.Color.MistyRose
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(201, 148)
        Me.txt_name.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(125, 26)
        Me.txt_name.TabIndex = 9
        '
        'txt_product_id
        '
        Me.txt_product_id.BackColor = System.Drawing.Color.MistyRose
        Me.txt_product_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_product_id.Location = New System.Drawing.Point(201, 103)
        Me.txt_product_id.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_product_id.Name = "txt_product_id"
        Me.txt_product_id.Size = New System.Drawing.Size(125, 26)
        Me.txt_product_id.TabIndex = 8
        '
        'lst_product_id
        '
        Me.lst_product_id.BackColor = System.Drawing.Color.MistyRose
        Me.lst_product_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_product_id.FormattingEnabled = True
        Me.lst_product_id.ItemHeight = 20
        Me.lst_product_id.Location = New System.Drawing.Point(527, 103)
        Me.lst_product_id.Margin = New System.Windows.Forms.Padding(1)
        Me.lst_product_id.Name = "lst_product_id"
        Me.lst_product_id.Size = New System.Drawing.Size(135, 424)
        Me.lst_product_id.TabIndex = 7
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Tomato
        Me.lbl_title.Font = New System.Drawing.Font("Showcard Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(193, 20)
        Me.lbl_title.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(346, 46)
        Me.lbl_title.TabIndex = 6
        Me.lbl_title.Text = "PRODUCT DETAILS"
        '
        'txt_type
        '
        Me.txt_type.BackColor = System.Drawing.Color.MistyRose
        Me.txt_type.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_type.Location = New System.Drawing.Point(201, 337)
        Me.txt_type.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_type.Name = "txt_type"
        Me.txt_type.Size = New System.Drawing.Size(294, 26)
        Me.txt_type.TabIndex = 12
        '
        'txt_size
        '
        Me.txt_size.BackColor = System.Drawing.Color.MistyRose
        Me.txt_size.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_size.Location = New System.Drawing.Point(201, 246)
        Me.txt_size.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_size.Name = "txt_size"
        Me.txt_size.Size = New System.Drawing.Size(125, 26)
        Me.txt_size.TabIndex = 14
        '
        'txt_manufacturer
        '
        Me.txt_manufacturer.BackColor = System.Drawing.Color.MistyRose
        Me.txt_manufacturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_manufacturer.Location = New System.Drawing.Point(201, 294)
        Me.txt_manufacturer.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_manufacturer.Name = "txt_manufacturer"
        Me.txt_manufacturer.Size = New System.Drawing.Size(125, 26)
        Me.txt_manufacturer.TabIndex = 15
        '
        'lbl_id
        '
        Me.lbl_id.AutoSize = True
        Me.lbl_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_id.Location = New System.Drawing.Point(85, 106)
        Me.lbl_id.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_id.Name = "lbl_id"
        Me.lbl_id.Size = New System.Drawing.Size(112, 20)
        Me.lbl_id.TabIndex = 17
        Me.lbl_id.Text = "PRODUCT ID:"
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_name.Location = New System.Drawing.Point(56, 151)
        Me.lbl_name.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(141, 20)
        Me.lbl_name.TabIndex = 18
        Me.lbl_name.Text = "PRODUCT NAME:"
        '
        'lbl_price
        '
        Me.lbl_price.AutoSize = True
        Me.lbl_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_price.Location = New System.Drawing.Point(135, 199)
        Me.lbl_price.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_price.Name = "lbl_price"
        Me.lbl_price.Size = New System.Drawing.Size(62, 20)
        Me.lbl_price.TabIndex = 19
        Me.lbl_price.Text = "PRICE:"
        '
        'lbl_size
        '
        Me.lbl_size.AutoSize = True
        Me.lbl_size.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_size.Location = New System.Drawing.Point(149, 246)
        Me.lbl_size.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_size.Name = "lbl_size"
        Me.lbl_size.Size = New System.Drawing.Size(50, 20)
        Me.lbl_size.TabIndex = 20
        Me.lbl_size.Text = "SIZE:"
        '
        'lbl_type
        '
        Me.lbl_type.AutoSize = True
        Me.lbl_type.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_type.Location = New System.Drawing.Point(143, 337)
        Me.lbl_type.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_type.Name = "lbl_type"
        Me.lbl_type.Size = New System.Drawing.Size(54, 20)
        Me.lbl_type.TabIndex = 21
        Me.lbl_type.Text = "TYPE:"
        '
        'lbl_manufacturer
        '
        Me.lbl_manufacturer.AutoSize = True
        Me.lbl_manufacturer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_manufacturer.Location = New System.Drawing.Point(104, 294)
        Me.lbl_manufacturer.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_manufacturer.Name = "lbl_manufacturer"
        Me.lbl_manufacturer.Size = New System.Drawing.Size(80, 20)
        Me.lbl_manufacturer.TabIndex = 22
        Me.lbl_manufacturer.Text = "MADE IN:"
        '
        'lbl_description
        '
        Me.lbl_description.AutoSize = True
        Me.lbl_description.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_description.Location = New System.Drawing.Point(75, 380)
        Me.lbl_description.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lbl_description.Name = "lbl_description"
        Me.lbl_description.Size = New System.Drawing.Size(122, 20)
        Me.lbl_description.TabIndex = 23
        Me.lbl_description.Text = "DESCRIPTION:"
        '
        'txt_description
        '
        Me.txt_description.BackColor = System.Drawing.Color.MistyRose
        Me.txt_description.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_description.Location = New System.Drawing.Point(201, 380)
        Me.txt_description.Margin = New System.Windows.Forms.Padding(1)
        Me.txt_description.Multiline = True
        Me.txt_description.Name = "txt_description"
        Me.txt_description.Size = New System.Drawing.Size(294, 147)
        Me.txt_description.TabIndex = 13
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.Salmon
        Me.btn_back.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(60, 482)
        Me.btn_back.Margin = New System.Windows.Forms.Padding(1)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(109, 45)
        Me.btn_back.TabIndex = 24
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'frm_productdetails_a164854
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LemonChiffon
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(770, 542)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.lbl_description)
        Me.Controls.Add(Me.lbl_manufacturer)
        Me.Controls.Add(Me.lbl_type)
        Me.Controls.Add(Me.lbl_size)
        Me.Controls.Add(Me.lbl_price)
        Me.Controls.Add(Me.lbl_name)
        Me.Controls.Add(Me.lbl_id)
        Me.Controls.Add(Me.txt_manufacturer)
        Me.Controls.Add(Me.txt_size)
        Me.Controls.Add(Me.txt_description)
        Me.Controls.Add(Me.txt_type)
        Me.Controls.Add(Me.pic_product)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.txt_product_id)
        Me.Controls.Add(Me.lst_product_id)
        Me.Controls.Add(Me.lbl_title)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "frm_productdetails_a164854"
        Me.Text = "frm_productdetails_a164854"
        CType(Me.pic_product, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pic_product As PictureBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents txt_product_id As TextBox
    Friend WithEvents lst_product_id As ListBox
    Friend WithEvents lbl_title As Label
    Friend WithEvents txt_type As TextBox
    Friend WithEvents txt_size As TextBox
    Friend WithEvents txt_manufacturer As TextBox
    Friend WithEvents lbl_id As Label
    Friend WithEvents lbl_name As Label
    Friend WithEvents lbl_price As Label
    Friend WithEvents lbl_size As Label
    Friend WithEvents lbl_type As Label
    Friend WithEvents lbl_manufacturer As Label
    Friend WithEvents lbl_description As Label
    Friend WithEvents txt_description As TextBox
    Friend WithEvents btn_back As Button
End Class
