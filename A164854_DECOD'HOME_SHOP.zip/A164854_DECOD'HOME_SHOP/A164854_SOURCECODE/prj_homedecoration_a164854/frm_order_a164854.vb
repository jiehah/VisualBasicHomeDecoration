﻿Public Class frm_order_a164854
    Dim t As Double

    Private Sub frm_payment_A164854_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim mysql As String = "SELECT FLD_ORDER_ID FROM TBL_ORDER_A164854"
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        cmb_id.DataSource = mydatatable
        cmb_id.DisplayMember = "FLD_ORDER_ID"

        refresh_text(cmb_id.Text)
        refresh_grid()
        refresh_price()
    End Sub

    Private Sub refresh_text(ByVal orderId As String)

        Dim mysql As String = "SELECT * FROM TBL_ORDER_A164854 WHERE FLD_ORDER_ID='" & orderId & "'"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        tb_custid.Text = mydatatable.Rows(0).Item("FLD_CUSTOMER_ID")
        tb_sttaffid.Text = mydatatable.Rows(0).Item("FLD_STAFF_ID")

    End Sub

    Private Sub refresh_grid()

        Dim mysql As String = "SELECT FLD_PRODUCT_ID,FLD_PRODUCT_NAME,FLD_QUANTITY, FLD_PRICE FROM TBL_ITEM_LIST_A164854 where FLD_ORDER_ID like""%" & cmb_id.Text & "%"""
        Dim mydatatable As New DataTable
        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)
        myreader.Fill(mydatatable)
        order.DataSource = mydatatable

        order.Columns(0).HeaderText = "Product ID"
        order.Columns(1).HeaderText = "Product Name"
        order.Columns(2).HeaderText = "Order Quantity"
        order.Columns(3).HeaderText = "Total price"

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        frm_makeorder_a164854.Show()
        Me.Close()
    End Sub

    Private Sub cmb_id_MouseClick(sender As System.Object, e As System.EventArgs) Handles cmb_id.MouseClick
        refresh_text(cmb_id.Text)
    End Sub

    Private Sub cmb_id_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmb_id.SelectedIndexChanged
        refresh_grid()
        lbl_id.Text = cmb_id.Text
        refresh_price()
    End Sub

    Private Sub refresh_price()

        If order.RowCount > 1 Then
            t = 0
            For index As Integer = 0 To order.RowCount - 1
                t += Convert.ToDouble(order.Rows(index).Cells(3).Value)
            Next
            lbl_total.Text = "RM " & t
        ElseIf order.RowCount = 1 Then
            lbl_total.Text = "RM 0"
        End If

    End Sub

    Private Sub pic_home_Click(sender As Object, e As EventArgs) Handles pic_home.Click
        frm_mainmenu_a164854.Show()
        Me.Close()

    End Sub
End Class