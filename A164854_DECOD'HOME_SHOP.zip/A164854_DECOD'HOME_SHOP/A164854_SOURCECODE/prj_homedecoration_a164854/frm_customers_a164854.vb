﻿Public Class frm_customers_a164854
    Private Sub frm_customers_a164854_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim mysql As String = "SELECT * FROM TBL_CUSTOMER_A164854"

        Dim mydatatable As New DataTable

        Dim myreader As New OleDb.OleDbDataAdapter(mysql, myconnection)

        myreader.Fill(mydatatable)

        grd_customers.DataSource = mydatatable

    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click


        frm_mainmenu_a164854.Show()
        Me.Close()

    End Sub

    Private Sub btn_insert_Click(sender As Object, e As EventArgs) Handles btn_insert.Click


        frm_insertcustomer_a164854.Show()
        Me.Close()

    End Sub

    Private Sub btn_updatedelete_Click(sender As Object, e As EventArgs) Handles btn_updatedelete.Click


        frm_updatecustomer_a164854.Show()
        Me.Close()
    End Sub
End Class